Hi there!

If you're submitting a bug, please run `:call Gitv_GetDebugInfo()` and paste your clipboard here.

Otherwise, please disregard this message.
